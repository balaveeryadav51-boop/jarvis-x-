package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user", "jarvis", "system"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val commandAction: String? = null,
    val isOffline: Boolean = false,
    val isSpoken: Boolean = false
)
