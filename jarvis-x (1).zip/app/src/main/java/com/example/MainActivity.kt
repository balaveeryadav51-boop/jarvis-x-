package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.firebase.configureAppCheck
import com.example.ui.JarvisDashboardScreen
import com.example.ui.JarvisViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check configuration with launch intent before UI/Firebase
        configureAppCheck(this, intent)

        // STEP 2: Safe Android Intent execution channel for allowlisted commands
        viewModel.onLaunchIntent = { intent ->
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Log.e("MainActivity", "Failed to start intent: ${intent.action}", e)
            }
        }

        // STEP 3: Enable edge-to-edge
        enableEdgeToEdge()

        // STEP 4: Render UI
        setContent {
            MyApplicationTheme {
                JarvisDashboardScreen(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
    }
}
