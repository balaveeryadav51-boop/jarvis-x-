package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisCardBg
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyExplanationSheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JarvisSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("privacy_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = CyanElectric, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Privacy & Security Protocol",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            PrivacyItem(
                title = "Zero Secret Recording",
                desc = "The microphone is ONLY activated when you deliberately tap the microphone button or explicitly activate the user-enabled foreground service. A persistent notification is always visible during background operation.",
                icon = Icons.Default.Mic
            )

            PrivacyItem(
                title = "Local Room SQLite Storage",
                desc = "Conversation transcripts and offline notes remain stored locally in your device's private SQLite database. You can purge history at any moment with the Clear History control.",
                icon = Icons.Default.Lock
            )

            PrivacyItem(
                title = "Firebase App Check Zero-Trust",
                desc = "No API keys are packaged inside the APK. Gemini AI calls are attested through Firebase App Check and Play Integrity tokens, protecting backend resources from abuse.",
                icon = Icons.Default.Security
            )

            PrivacyItem(
                title = "Explicit Sensitive Action Gates",
                desc = "Device intents that launch external apps, initiate searches, or purge data require explicit on-screen confirmation before execution.",
                icon = Icons.Default.Info
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RealDeviceTestingSheet(onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JarvisSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("testing_guide_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.PhoneAndroid, contentDescription = null, tint = BlueNeon, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Real-Device Testing Checklist",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            TestingCheckItem(
                number = "01",
                feature = "Android SpeechRecognizer Service",
                detail = "Most browser streaming emulators do NOT bundle the Google Speech Services APK. On a physical phone, SpeechRecognizer connects to the on-device speech engine for instant transcription in English and Hindi."
            )

            TestingCheckItem(
                number = "02",
                feature = "Acoustic Wake-Word & Hardware DSP",
                detail = "Continuous 'Hey Jarvis' keyword detection requires OEM hardware low-power audio DSP chips and dedicated acoustic models (.ppn / ONNX) to prevent severe battery drain."
            )

            TestingCheckItem(
                number = "03",
                feature = "Android 14+ Foreground Microphone Service",
                detail = "Requires physical device notification shade testing to ensure the ongoing microphone service notification with 'Stop Listening' action satisfies Android 14+ background mic limits."
            )

            TestingCheckItem(
                number = "04",
                feature = "Native Camera & System Settings Intents",
                detail = "Intents like opening camera viewfinder, system alarm clock, and Wi-Fi configuration resolve to real device hardware activities."
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PrivacyItem(title: String, desc: String, icon: ImageVector) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(JarvisCardBg, RoundedCornerShape(12.dp))
            .border(1.dp, JarvisBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(imageVector = icon, contentDescription = null, tint = CyanElectric, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = desc, style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp), color = TextSecondary)
            }
        }
    }
}

@Composable
private fun TestingCheckItem(number: String, feature: String, detail: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(JarvisCardBg, RoundedCornerShape(12.dp))
            .border(1.dp, JarvisBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Text(
                text = number,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                color = BlueNeon
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = feature, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = detail, style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp), color = TextSecondary)
            }
        }
    }
}
