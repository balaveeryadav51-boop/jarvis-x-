package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JARVIS X Premium Deep Navy & Electric Blue Palette
val JarvisBackground = Color(0xFF040814)
val JarvisSurface = Color(0xFF0A1226)
val JarvisSurfaceVariant = Color(0xFF101C38)
val JarvisCardBg = Color(0xFF0E1830)
val JarvisBorder = Color(0xFF1A2B50)
val JarvisBorderGlow = Color(0xFF00E5FF)

// Electric accents
val CyanElectric = Color(0xFF00E5FF)
val CyanGlow = Color(0x6600E5FF)
val CyanDark = Color(0xFF0090A8)

val BlueNeon = Color(0xFF2979FF)
val BlueDeep = Color(0xFF1565C0)
val VioletArc = Color(0xFF7C4DFF)

// Text
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF90A4BE)
val TextMuted = Color(0xFF5C6F8C)

// Status
val StatusGreen = Color(0xFF00E676)
val StatusAmber = Color(0xFFFFB300)
val StatusRed = Color(0xFFFF5252)

// User bubble & Assistant bubble
val UserBubble = Color(0xFF152A55)
val AssistantBubble = Color(0xFF0D1C38)
