package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.ModularWakeWordEngine
import com.example.audio.SpeechRecognizerHelper
import com.example.audio.TextToSpeechHelper
import com.example.command.CommandAction
import com.example.command.CommandRouter
import com.example.command.CommandType
import com.example.data.local.ChatMessageEntity
import com.example.data.local.JarvisDatabase
import com.example.data.local.LocalNoteEntity
import com.example.firebase.JarvisAiClient
import com.example.service.JarvisForegroundVoiceService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

private const val TAG = "JarvisViewModel"

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val database = JarvisDatabase.getDatabase(context)
    private val dao = database.jarvisDao()

    private val aiClient = JarvisAiClient()
    private val commandRouter = CommandRouter(context)
    val speechRecognizerHelper = SpeechRecognizerHelper(context)
    val ttsHelper = TextToSpeechHelper(context)
    val wakeWordEngine = ModularWakeWordEngine()

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    // Intent execution channel callback
    var onLaunchIntent: ((Intent) -> Unit)? = null

    init {
        monitorNetwork()
        observeDatabase()
        setupAudioHelpers()
    }

    private fun monitorNetwork() {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val isInitiallyOnline = cm?.activeNetwork?.let { network ->
            cm.getNetworkCapabilities(network)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } ?: false

        _uiState.update { it.copy(isOnline = isInitiallyOnline) }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        cm?.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                _uiState.update { it.copy(isOnline = true) }
            }

            override fun onLost(network: Network) {
                _uiState.update { it.copy(isOnline = false) }
            }
        })
    }

    private fun observeDatabase() {
        viewModelScope.launch {
            dao.getAllMessages().collect { list ->
                _uiState.update { it.copy(messages = list) }
            }
        }
        viewModelScope.launch {
            dao.getAllNotes().collect { notesList ->
                _uiState.update { it.copy(notes = notesList) }
            }
        }
    }

    private fun setupAudioHelpers() {
        // Collect real-time speech amplitude
        viewModelScope.launch {
            speechRecognizerHelper.audioAmplitude.collect { amp ->
                _uiState.update { it.copy(audioAmplitude = amp) }
            }
        }

        // Collect partial speech results
        viewModelScope.launch {
            speechRecognizerHelper.partialText.collect { partial ->
                _uiState.update { it.copy(partialSpeechText = partial) }
            }
        }

        // Speech recognition callbacks
        speechRecognizerHelper.onResultListener = { recognizedText ->
            handleUserSpeechInput(recognizedText)
        }

        speechRecognizerHelper.onErrorListener = { errorMsg ->
            _uiState.update {
                it.copy(
                    status = AssistantStatus.IDLE,
                    errorMessage = errorMsg
                )
            }
        }

        // TTS speaking status listener
        viewModelScope.launch {
            ttsHelper.isSpeaking.collect { speaking ->
                _uiState.update { current ->
                    if (speaking) {
                        current.copy(status = AssistantStatus.SPEAKING)
                    } else if (current.status == AssistantStatus.SPEAKING) {
                        current.copy(status = AssistantStatus.IDLE)
                    } else {
                        current
                    }
                }
            }
        }

        // TTS mute listener
        viewModelScope.launch {
            ttsHelper.isMuted.collect { muted ->
                _uiState.update { it.copy(isTtsMuted = muted) }
            }
        }
    }

    fun onTextInputChange(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun startVoiceListening() {
        vibratePhone()
        ttsHelper.stop()
        val speechCode = _uiState.value.languageMode.speechCode
        speechRecognizerHelper.startListening(speechCode)
        _uiState.update {
            it.copy(
                status = AssistantStatus.LISTENING,
                errorMessage = null,
                partialSpeechText = ""
            )
        }
    }

    fun stopVoiceListening() {
        vibratePhone()
        speechRecognizerHelper.stopListening()
        if (_uiState.value.partialSpeechText.isNotBlank()) {
            handleUserSpeechInput(_uiState.value.partialSpeechText)
        } else {
            _uiState.update { it.copy(status = AssistantStatus.IDLE) }
        }
    }

    private fun handleUserSpeechInput(text: String) {
        val trimmed = text.trim()
        if (trimmed.isNotBlank()) {
            _uiState.update { it.copy(inputText = "", partialSpeechText = "") }
            processUserMessage(trimmed)
        } else {
            _uiState.update { it.copy(status = AssistantStatus.IDLE) }
        }
    }

    fun sendTextMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isNotBlank()) {
            _uiState.update { it.copy(inputText = "") }
            processUserMessage(text)
        }
    }

    fun sendPredefinedCommand(commandText: String) {
        processUserMessage(commandText)
    }

    private fun processUserMessage(userInput: String) {
        viewModelScope.launch {
            // Save user message to Room
            dao.insertMessage(
                ChatMessageEntity(
                    role = "user",
                    content = userInput,
                    timestamp = System.currentTimeMillis()
                )
            )

            val isHindi = _uiState.value.languageMode == LanguageMode.HINDI || 
                          _uiState.value.languageMode == LanguageMode.HINGLISH

            // 1. Check Allowlisted Command Router first
            val matchedCommand = commandRouter.parseCommand(userInput, isHindi)

            if (matchedCommand != null) {
                handleAllowlistedCommand(matchedCommand)
                return@launch
            }

            // 2. No command matched -> Check online status for Gemini AI Logic
            if (!_uiState.value.isOnline) {
                // Offline mode handling
                val offlineReply = if (isHindi) {
                    "JARVIS X offline mode me hai. Internet connection ke bina online neural model uplabdh nahi hai. Aap device commands (battery, time, alarm, camera, notes) chala sakte hain."
                } else {
                    "JARVIS X is running in Offline Mode. Full Gemini neural processing requires an active internet connection. You can still use local commands: check battery, time, save notes, or open settings."
                }
                saveAssistantReply(offlineReply, isOffline = true)
                return@launch
            }

            // 3. Online Gemini AI Logic inference
            _uiState.update { it.copy(status = AssistantStatus.PROCESSING) }

            // Extract last few messages for conversational context
            val recentEntities = dao.getRecentMessages(6).reversed()
            val history = recentEntities.map { entity ->
                val roleName = if (entity.role == "user") "User" else "JARVIS"
                Pair(roleName, entity.content)
            }

            val result = aiClient.generateResponse(userInput, history)
            result.onSuccess { responseText ->
                saveAssistantReply(responseText, isOffline = false)
            }.onFailure { error ->
                Log.w(TAG, "Gemini generation failed, falling back to local assistant response: ${error.message}")
                val fallbackMsg = if (isHindi) {
                    "Maaf kijiye, neural core se sampark nahi ho paya: ${error.localizedMessage}. Aap local commands chala sakte hain."
                } else {
                    "Neural core communication failed: ${error.localizedMessage}. Operating in local backup mode."
                }
                saveAssistantReply(fallbackMsg, isOffline = true)
            }
        }
    }

    private fun handleAllowlistedCommand(command: CommandAction) {
        viewModelScope.launch {
            if (command.requiresConfirmation) {
                // Set pending confirmation action to display confirmation dialog/sheet
                _uiState.update {
                    it.copy(
                        status = AssistantStatus.IDLE,
                        pendingConfirmationAction = command
                    )
                }
                return@launch
            }

            // Safe Intent execution
            if (command.type == CommandType.SAFE_INTENT && command.intent != null) {
                try {
                    onLaunchIntent?.invoke(command.intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to launch intent: ${command.title}", e)
                }
            } else if (command.id == "CREATE_NOTE") {
                // Save note locally
                val noteText = command.description
                if (noteText.isNotBlank()) {
                    dao.insertNote(LocalNoteEntity(title = "Voice Memo", content = noteText))
                }
            }

            val reply = command.feedbackMessage
            saveAssistantReply(reply, commandAction = command.id, isOffline = command.isOfflineCapable)
        }
    }

    fun confirmPendingAction() {
        val action = _uiState.value.pendingConfirmationAction ?: return
        _uiState.update { it.copy(pendingConfirmationAction = null) }

        viewModelScope.launch {
            if (action.id == "CLEAR_HISTORY") {
                dao.clearHistory()
                val reply = "Conversation history has been purged from local storage, sir."
                saveAssistantReply(reply, isOffline = true)
            } else if (action.intent != null) {
                try {
                    onLaunchIntent?.invoke(action.intent)
                    saveAssistantReply("Launching ${action.title}.", commandAction = action.id, isOffline = false)
                } catch (e: Exception) {
                    saveAssistantReply("Unable to launch activity: ${e.localizedMessage}", isOffline = true)
                }
            }
        }
    }

    fun dismissPendingAction() {
        _uiState.update { it.copy(pendingConfirmationAction = null) }
    }

    private suspend fun saveAssistantReply(
        text: String,
        commandAction: String? = null,
        isOffline: Boolean = false
    ) {
        dao.insertMessage(
            ChatMessageEntity(
                role = "jarvis",
                content = text,
                timestamp = System.currentTimeMillis(),
                commandAction = commandAction,
                isOffline = isOffline
            )
        )

        _uiState.update { it.copy(status = AssistantStatus.SPEAKING) }
        ttsHelper.speak(text)
    }

    fun speakMessage(text: String) {
        ttsHelper.speak(text)
    }

    fun stopSpeaking() {
        ttsHelper.stop()
    }

    fun toggleMuteTts() {
        ttsHelper.toggleMute()
    }

    fun setLanguageMode(mode: LanguageMode) {
        _uiState.update { it.copy(languageMode = mode) }
        val ttsCode = if (mode == LanguageMode.HINDI) "hi-IN" else "en-US"
        ttsHelper.setLanguage(ttsCode)
    }

    fun clearHistory() {
        viewModelScope.launch {
            dao.clearHistory()
        }
    }

    fun saveLocalNote(title: String, content: String) {
        viewModelScope.launch {
            dao.insertNote(
                LocalNoteEntity(
                    title = if (title.isBlank()) "Quick Note" else title.trim(),
                    content = content.trim()
                )
            )
        }
    }

    fun deleteLocalNote(id: Long) {
        viewModelScope.launch {
            dao.deleteNote(id)
        }
    }

    fun toggleForegroundVoiceService() {
        val currentState = _uiState.value.isForegroundServiceActive
        if (!currentState) {
            JarvisForegroundVoiceService.startService(context)
            _uiState.update { it.copy(isForegroundServiceActive = true) }
        } else {
            JarvisForegroundVoiceService.stopService(context)
            _uiState.update { it.copy(isForegroundServiceActive = false) }
        }
    }

    fun toggleWakeWord() {
        val currentlyEnabled = _uiState.value.isWakeWordEnabled
        if (!currentlyEnabled) {
            val result = wakeWordEngine.startListening { phrase ->
                processUserMessage(phrase)
            }
            if (result.isFailure) {
                _uiState.update {
                    it.copy(
                        isWakeWordEnabled = false,
                        wakeWordStatusText = "Unavailable: ${result.exceptionOrNull()?.message}"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isWakeWordEnabled = true,
                        wakeWordStatusText = "Active"
                    )
                }
            }
        } else {
            wakeWordEngine.stopListening()
            _uiState.update {
                it.copy(
                    isWakeWordEnabled = false,
                    wakeWordStatusText = "Standby (Modular interface ready)"
                )
            }
        }
    }

    fun showBottomSheet(type: BottomSheetType) {
        _uiState.update { it.copy(activeBottomSheet = type) }
    }

    fun dismissBottomSheet() {
        _uiState.update { it.copy(activeBottomSheet = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun vibratePhone() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizerHelper.destroy()
        ttsHelper.shutdown()
    }
}
