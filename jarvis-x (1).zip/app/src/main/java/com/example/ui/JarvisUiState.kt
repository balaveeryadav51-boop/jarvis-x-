package com.example.ui

import com.example.command.CommandAction
import com.example.data.local.ChatMessageEntity
import com.example.data.local.LocalNoteEntity

enum class AssistantStatus {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    OFFLINE
}

enum class LanguageMode(val displayName: String, val speechCode: String) {
    ENGLISH("English", "en-US"),
    HINGLISH("Hinglish", "hi-IN"),
    HINDI("हिन्दी", "hi-IN")
}

data class JarvisUiState(
    val status: AssistantStatus = AssistantStatus.IDLE,
    val isOnline: Boolean = true,
    val languageMode: LanguageMode = LanguageMode.ENGLISH,
    val messages: List<ChatMessageEntity> = emptyList(),
    val notes: List<LocalNoteEntity> = emptyList(),
    val inputText: String = "",
    val partialSpeechText: String = "",
    val audioAmplitude: Float = 0f,
    val isTtsMuted: Boolean = false,
    val isForegroundServiceActive: Boolean = false,
    val isWakeWordEnabled: Boolean = false,
    val wakeWordStatusText: String = "Standby (Requires on-device model)",
    val pendingConfirmationAction: CommandAction? = null,
    val activeBottomSheet: BottomSheetType? = null,
    val errorMessage: String? = null
)

enum class BottomSheetType {
    HISTORY,
    SETTINGS,
    NOTES,
    PRIVACY,
    TESTING_GUIDE
}
