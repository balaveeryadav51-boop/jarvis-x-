package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BottomVoiceBar
import com.example.ui.components.ChatSection
import com.example.ui.components.CircularVoiceWaveform
import com.example.ui.components.CommandSuggestionsBar
import com.example.ui.components.ConfirmationDialog
import com.example.ui.components.HistoryBottomSheet
import com.example.ui.components.JarvisHeader
import com.example.ui.components.OfflineNotesSheet
import com.example.ui.components.PrivacyExplanationSheet
import com.example.ui.components.RealDeviceTestingSheet
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.theme.JarvisBackground

@Composable
fun JarvisDashboardScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Audio recording permission launcher
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startVoiceListening()
        } else {
            Toast.makeText(context, "Microphone permission is required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    // Notification permission launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleForegroundVoiceService()
        }
    }

    // Display error messages in snackbar
    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { error ->
            snackbarHostState.showSnackbar(error)
            viewModel.clearError()
        }
    }

    // Handle Back Press when modal sheets are open
    BackHandler(enabled = uiState.activeBottomSheet != null || uiState.pendingConfirmationAction != null) {
        if (uiState.pendingConfirmationAction != null) {
            viewModel.dismissPendingAction()
        } else if (uiState.activeBottomSheet != null) {
            viewModel.dismissBottomSheet()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisBackground)
            .statusBarsPadding()
            .testTag("jarvis_dashboard_screen"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            JarvisHeader(
                status = uiState.status,
                isOnline = uiState.isOnline,
                currentLanguage = uiState.languageMode,
                isTtsMuted = uiState.isTtsMuted,
                onLanguageSelected = { viewModel.setLanguageMode(it) },
                onToggleMute = { viewModel.toggleMuteTts() },
                onOpenSheet = { viewModel.showBottomSheet(it) }
            )
        },
        bottomBar = {
            BottomVoiceBar(
                status = uiState.status,
                inputText = uiState.inputText,
                onInputChange = { viewModel.onTextInputChange(it) },
                onSendMessage = { viewModel.sendTextMessage() },
                onStartListening = {
                    val hasMicPermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (hasMicPermission) {
                        viewModel.startVoiceListening()
                    } else {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onStopListening = { viewModel.stopVoiceListening() },
                onStopSpeaking = { viewModel.stopSpeaking() }
            )
        },
        containerColor = JarvisBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Animated Voice Reactor Header / Waveform
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularVoiceWaveform(
                    status = uiState.status,
                    audioAmplitude = uiState.audioAmplitude,
                    size = 110.dp
                )
            }

            // Quick allowlisted command suggestions
            CommandSuggestionsBar(
                languageMode = uiState.languageMode,
                onSelectCommand = { viewModel.sendPredefinedCommand(it) }
            )

            // Conversation Chat List
            ChatSection(
                messages = uiState.messages,
                status = uiState.status,
                partialSpeechText = uiState.partialSpeechText,
                onSpeakMessage = { viewModel.speakMessage(it) },
                modifier = Modifier.weight(1f)
            )
        }
    }

    // Modal Confirmation Dialog for sensitive actions
    uiState.pendingConfirmationAction?.let { action ->
        ConfirmationDialog(
            action = action,
            onConfirm = { viewModel.confirmPendingAction() },
            onDismiss = { viewModel.dismissPendingAction() }
        )
    }

    // Active Bottom Sheets
    when (uiState.activeBottomSheet) {
        BottomSheetType.HISTORY -> {
            HistoryBottomSheet(
                messages = uiState.messages,
                onClearHistory = {
                    viewModel.dismissBottomSheet()
                    viewModel.sendPredefinedCommand("clear chat")
                },
                onDismiss = { viewModel.dismissBottomSheet() }
            )
        }
        BottomSheetType.SETTINGS -> {
            SettingsBottomSheet(
                isForegroundActive = uiState.isForegroundServiceActive,
                isWakeWordEnabled = uiState.isWakeWordEnabled,
                wakeWordStatus = uiState.wakeWordStatusText,
                isTtsMuted = uiState.isTtsMuted,
                onToggleForegroundService = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val hasNotificationPermission = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) == PackageManager.PERMISSION_GRANTED
                        if (!hasNotificationPermission) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            return@SettingsBottomSheet
                        }
                    }
                    viewModel.toggleForegroundVoiceService()
                },
                onToggleWakeWord = { viewModel.toggleWakeWord() },
                onToggleMute = { viewModel.toggleMuteTts() },
                onOpenSheet = { viewModel.showBottomSheet(it) },
                onDismiss = { viewModel.dismissBottomSheet() }
            )
        }
        BottomSheetType.NOTES -> {
            OfflineNotesSheet(
                notes = uiState.notes,
                onSaveNote = { title, content -> viewModel.saveLocalNote(title, content) },
                onDeleteNote = { id -> viewModel.deleteLocalNote(id) },
                onDismiss = { viewModel.dismissBottomSheet() }
            )
        }
        BottomSheetType.PRIVACY -> {
            PrivacyExplanationSheet(onDismiss = { viewModel.dismissBottomSheet() })
        }
        BottomSheetType.TESTING_GUIDE -> {
            RealDeviceTestingSheet(onDismiss = { viewModel.dismissBottomSheet() })
        }
        null -> {}
    }
}
