package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.BottomSheetType
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisCardBg
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletArc

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    isForegroundActive: Boolean,
    isWakeWordEnabled: Boolean,
    wakeWordStatus: String,
    isTtsMuted: Boolean,
    onToggleForegroundService: () -> Unit,
    onToggleWakeWord: () -> Unit,
    onToggleMute: () -> Unit,
    onOpenSheet: (BottomSheetType) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var speechRate by remember { mutableFloatStateOf(1.05f) }
    var speechPitch by remember { mutableFloatStateOf(1.0f) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = JarvisSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("settings_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = CyanElectric,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "JARVIS X Configuration",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 1: Voice & Speech Engine
            SettingsSectionTitle(title = "SPEECH SYNTHESIZER (TTS)", icon = Icons.Default.RecordVoiceOver)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JarvisCardBg, RoundedCornerShape(14.dp))
                    .border(1.dp, JarvisBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Voice Responses",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimary
                            )
                            Text(
                                text = if (isTtsMuted) "Muted (Text only)" else "Active (Spoken replies)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Switch(
                            checked = !isTtsMuted,
                            onCheckedChange = { onToggleMute() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = CyanElectric,
                                uncheckedTrackColor = JarvisBorder
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Speech Rate: ${"%.2f".format(speechRate)}x",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Slider(
                        value = speechRate,
                        onValueChange = { speechRate = it },
                        valueRange = 0.7f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyanElectric,
                            activeTrackColor = CyanElectric,
                            inactiveTrackColor = JarvisBorder
                        )
                    )

                    Text(
                        text = "Pitch: ${"%.2f".format(speechPitch)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Slider(
                        value = speechPitch,
                        onValueChange = { speechPitch = it },
                        valueRange = 0.8f..1.3f,
                        colors = SliderDefaults.colors(
                            thumbColor = BlueNeon,
                            activeTrackColor = BlueNeon,
                            inactiveTrackColor = JarvisBorder
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 2: User-Enabled Foreground Voice Service
            SettingsSectionTitle(title = "USER-ENABLED FOREGROUND SERVICE", icon = Icons.Default.NotificationsActive)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JarvisCardBg, RoundedCornerShape(14.dp))
                    .border(1.dp, JarvisBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Foreground Microphone Service",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimary
                            )
                            Text(
                                text = "Keeps voice listener active with ongoing system notification and stop button (Android 14+ FOREGROUND_SERVICE_MICROPHONE).",
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 16.sp),
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = isForegroundActive,
                            onCheckedChange = { onToggleForegroundService() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = CyanElectric,
                                uncheckedTrackColor = JarvisBorder
                            ),
                            modifier = Modifier.testTag("foreground_service_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isForegroundActive) "Status: Running (Foreground notification active)" else "Status: Stopped",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isForegroundActive) StatusGreen else TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 3: Modular Wake-Word Detector
            SettingsSectionTitle(title = "MODULAR WAKE-WORD DETECTOR", icon = Icons.Default.Mic)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(JarvisCardBg, RoundedCornerShape(14.dp))
                    .border(1.dp, JarvisBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "\"Hey Jarvis\" Voice Activation",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = TextPrimary
                            )
                            Text(
                                text = "Modular acoustic detection architecture. Evaluates pluggable low-power DSP models without unauthorized background recording.",
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 16.sp),
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Switch(
                            checked = isWakeWordEnabled,
                            onCheckedChange = { onToggleWakeWord() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = VioletArc,
                                uncheckedTrackColor = JarvisBorder
                            ),
                            modifier = Modifier.testTag("wake_word_toggle")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF060E20), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = wakeWordStatus,
                            style = MaterialTheme.typography.labelSmall,
                            color = StatusAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 4: Privacy & Real Device Testing
            SettingsSectionTitle(title = "DOCUMENTATION & COMPLIANCE", icon = Icons.Default.Security)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onOpenSheet(BottomSheetType.PRIVACY) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D1D3A)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = CyanElectric, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Privacy & Security", color = CyanElectric, style = MaterialTheme.typography.labelSmall)
                }

                Button(
                    onClick = { onOpenSheet(BottomSheetType.TESTING_GUIDE) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D1D3A)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.PhoneAndroid, contentDescription = null, tint = BlueNeon, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Real Device Guide", color = BlueNeon, style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = CyanDark, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            ),
            color = CyanDark
        )
    }
}
