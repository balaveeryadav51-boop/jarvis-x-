package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.LanguageMode
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisCardBg
import com.example.ui.theme.TextPrimary

@Composable
fun CommandSuggestionsBar(
    languageMode: LanguageMode,
    onSelectCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val suggestions = if (languageMode == LanguageMode.HINDI) {
        listOf(
            "🔋 Battery kitni hai?" to "battery kitni hai",
            "⏰ Alarm lagao" to "alarm lagao",
            "📸 Camera kholo" to "camera kholo",
            "⚙️ Settings kholo" to "setting kholo",
            "📶 Wi-Fi setting" to "wifi kholo",
            "🕒 Time kya hua hai?" to "time kya hua hai",
            "📝 Note likho: Meeting at 5pm" to "note likho: Meeting at 5pm",
            "🇮🇳 Namaste Jarvis" to "namaste jarvis",
            "🗑️ Clear chat" to "clear chat"
        )
    } else {
        listOf(
            "🔋 Battery Status" to "check battery",
            "⏰ Alarm Clock" to "open alarm",
            "📸 Open Camera" to "open camera",
            "⚙️ Settings" to "open settings",
            "📶 Wi-Fi Settings" to "open wifi",
            "🕒 What time is it?" to "what time is it",
            "📝 Note: Call Tony at 6" to "note Call Tony at 6",
            "🌐 Search: Mars Rover" to "search Mars Rover",
            "🗑️ Clear Chat" to "clear chat"
        )
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("command_suggestions_bar"),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        suggestions.forEach { (label, query) ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(JarvisCardBg)
                    .border(1.dp, JarvisBorder, RoundedCornerShape(16.dp))
                    .clickable { onSelectCommand(query) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("suggestion_chip_${query.take(8)}")
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = TextPrimary
                )
            }
        }
    }
}
