package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.AssistantStatus
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusRed
import com.example.ui.theme.VioletArc
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CircularVoiceWaveform(
    status: AssistantStatus,
    audioAmplitude: Float,
    modifier: Modifier = Modifier,
    size: Dp = 140.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")

    // Slow rotation of outer tech ticks
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Reverse rotation of inner ring
    val reverseRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "reverse_rotation"
    )

    // Breathing pulse for idle & processing
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )

    // Active wave pulse reacting to voice amplitude
    val dynamicScale = when (status) {
        AssistantStatus.LISTENING -> 1.0f + (audioAmplitude * 0.45f)
        AssistantStatus.SPEAKING -> 1.0f + (audioAmplitude.coerceAtLeast(0.15f) * 0.35f)
        AssistantStatus.PROCESSING -> idlePulse * 1.05f
        AssistantStatus.OFFLINE -> 0.95f
        AssistantStatus.IDLE -> idlePulse
    }

    val primaryColor = when (status) {
        AssistantStatus.LISTENING -> CyanElectric
        AssistantStatus.PROCESSING -> VioletArc
        AssistantStatus.SPEAKING -> BlueNeon
        AssistantStatus.OFFLINE -> StatusAmber
        AssistantStatus.IDLE -> CyanDark
    }

    Box(
        modifier = modifier
            .size(size)
            .testTag("circular_voice_waveform"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2f) * 0.75f
            val scaledRadius = baseRadius * dynamicScale

            // 1. Ambient Background Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = if (status == AssistantStatus.LISTENING) 0.35f else 0.18f),
                        primaryColor.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = scaledRadius * 1.35f
                ),
                radius = scaledRadius * 1.35f,
                center = center
            )

            // 2. Outer Technical Segmented Ring (Rotating)
            val segments = 24
            val segmentAngle = (2 * PI / segments).toFloat()
            for (i in 0 until segments) {
                if (i % 2 == 0) {
                    val angle = (i * segmentAngle) + (rotation * (PI.toFloat() / 180f))
                    val startDist = scaledRadius * 1.08f
                    val endDist = scaledRadius * 1.18f
                    val start = Offset(
                        center.x + cos(angle) * startDist,
                        center.y + sin(angle) * startDist
                    )
                    val end = Offset(
                        center.x + cos(angle) * endDist,
                        center.y + sin(angle) * endDist
                    )
                    drawLine(
                        color = primaryColor.copy(alpha = 0.55f),
                        start = start,
                        end = end,
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // 3. Middle Concentric Reactor Ring (Reverse rotating dashed ring)
            drawCircle(
                color = primaryColor.copy(alpha = 0.4f),
                radius = scaledRadius * 0.92f,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx()
                )
            )

            // 4. Reactive Waveform Nodes when Listening or Speaking
            if (status == AssistantStatus.LISTENING || status == AssistantStatus.SPEAKING) {
                val waveNodes = 12
                val waveAngleStep = (2 * PI / waveNodes).toFloat()
                for (j in 0 until waveNodes) {
                    val angle = (j * waveAngleStep) + (reverseRotation * (PI.toFloat() / 180f))
                    val nodeDist = scaledRadius * (0.85f + (sin((j * 3 + rotation).toDouble()) * 0.15f * audioAmplitude).toFloat())
                    val nodePos = Offset(
                        center.x + cos(angle) * nodeDist,
                        center.y + sin(angle) * nodeDist
                    )
                    drawCircle(
                        color = CyanElectric,
                        radius = (3.dp + (3.dp * audioAmplitude)).toPx(),
                        center = nodePos
                    )
                }
            }

            // 5. Inner Core Ring
            drawCircle(
                brush = Brush.linearGradient(
                    colors = listOf(primaryColor, BlueNeon)
                ),
                radius = scaledRadius * 0.65f,
                center = center,
                style = Stroke(width = 3.5.dp.toPx())
            )

            // 6. Central "X" Arc Reactor Core
            val coreRadius = scaledRadius * 0.42f
            drawCircle(
                color = primaryColor.copy(alpha = 0.25f),
                radius = coreRadius,
                center = center
            )

            // Draw stylized central "X"
            val xSpan = coreRadius * 0.6f
            drawLine(
                color = Color.White,
                start = Offset(center.x - xSpan, center.y - xSpan),
                end = Offset(center.x + xSpan, center.y + xSpan),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color.White,
                start = Offset(center.x + xSpan, center.y - xSpan),
                end = Offset(center.x - xSpan, center.y + xSpan),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Center glowing dot
            drawCircle(
                color = Color.White,
                radius = 2.5.dp.toPx(),
                center = center
            )
        }
    }
}
