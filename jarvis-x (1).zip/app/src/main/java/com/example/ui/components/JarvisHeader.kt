package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.AssistantStatus
import com.example.ui.BottomSheetType
import com.example.ui.LanguageMode
import com.example.ui.theme.BlueNeon
import com.example.ui.theme.CyanDark
import com.example.ui.theme.CyanElectric
import com.example.ui.theme.JarvisBorder
import com.example.ui.theme.JarvisCardBg
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletArc

@Composable
fun JarvisHeader(
    status: AssistantStatus,
    isOnline: Boolean,
    currentLanguage: LanguageMode,
    isTtsMuted: Boolean,
    onLanguageSelected: (LanguageMode) -> Unit,
    onToggleMute: () -> Unit,
    onOpenSheet: (BottomSheetType) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(JarvisCardBg)
            .border(width = 1.dp, color = JarvisBorder, shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("jarvis_header")
    ) {
        // Top Row: Brand + Status Pill + Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "JARVIS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    ),
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .background(
                            color = CyanElectric.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .border(1.dp, CyanElectric, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "X",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = CyanElectric
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Assistant Status Pill
                StatusPill(status = status, isOnline = isOnline)
            }

            // Top action buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                // TTS Mute button
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("mute_tts_button")
                ) {
                    Icon(
                        imageVector = if (isTtsMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                        contentDescription = if (isTtsMuted) "Unmute Speech" else "Mute Speech",
                        tint = if (isTtsMuted) StatusAmber else CyanElectric,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Notes Button
                IconButton(
                    onClick = { onOpenSheet(BottomSheetType.NOTES) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("offline_notes_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = "Offline Notes",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // History Button
                IconButton(
                    onClick = { onOpenSheet(BottomSheetType.HISTORY) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Conversation History",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Settings Button
                IconButton(
                    onClick = { onOpenSheet(BottomSheetType.SETTINGS) },
                    modifier = Modifier
                        .size(38.dp)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Sub Row: Online/Offline Badge + Language Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Connectivity Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onOpenSheet(BottomSheetType.PRIVACY) }
                    .background(Color(0xFF070F22))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (isOnline) StatusGreen else StatusAmber, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isOnline) "NEURAL ONLINE" else "OFFLINE MODE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    ),
                    color = if (isOnline) StatusGreen else StatusAmber
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Security details",
                    tint = TextMuted,
                    modifier = Modifier.size(12.dp)
                )
            }

            // Language selector chips: English, Hinglish, Hindi
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LanguageMode.entries.forEach { mode ->
                    val isSelected = currentLanguage == mode
                    val chipBg by animateColorAsState(
                        targetValue = if (isSelected) CyanElectric.copy(alpha = 0.25f) else Color(0xFF070F22),
                        label = "chip_bg"
                    )
                    val chipBorder = if (isSelected) CyanElectric else JarvisBorder

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(chipBg)
                            .border(1.dp, chipBorder, RoundedCornerShape(8.dp))
                            .clickable { onLanguageSelected(mode) }
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                            .testTag("lang_chip_${mode.name.lowercase()}")
                    ) {
                        Text(
                            text = mode.displayName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            ),
                            color = if (isSelected) CyanElectric else TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusPill(status: AssistantStatus, isOnline: Boolean) {
    val (statusLabel, statusColor) = when {
        status == AssistantStatus.LISTENING -> "LISTENING" to CyanElectric
        status == AssistantStatus.PROCESSING -> "PROCESSING" to VioletArc
        status == AssistantStatus.SPEAKING -> "SPEAKING" to BlueNeon
        !isOnline || status == AssistantStatus.OFFLINE -> "OFFLINE" to StatusAmber
        else -> "READY" to CyanDark
    }

    Box(
        modifier = Modifier
            .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
            .border(1.dp, statusColor.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .testTag("assistant_status_pill")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(statusColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = statusLabel,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = statusColor
            )
        }
    }
}
