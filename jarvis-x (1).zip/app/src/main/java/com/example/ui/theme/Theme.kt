package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = CyanElectric,
    onPrimary = Color(0xFF001A24),
    primaryContainer = Color(0xFF003848),
    onPrimaryContainer = Color(0xFF99F0FF),

    secondary = BlueNeon,
    onSecondary = Color(0xFF00174B),
    secondaryContainer = Color(0xFF0F3276),
    onSecondaryContainer = Color(0xFFD6E3FF),

    tertiary = VioletArc,
    onTertiary = Color(0xFF1D0052),
    tertiaryContainer = Color(0xFF381980),
    onTertiaryContainer = Color(0xFFE8DDFF),

    background = JarvisBackground,
    onBackground = TextPrimary,

    surface = JarvisSurface,
    onSurface = TextPrimary,
    surfaceVariant = JarvisSurfaceVariant,
    onSurfaceVariant = TextSecondary,

    outline = JarvisBorder,
    outlineVariant = Color(0xFF132242),
    error = StatusRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // JARVIS X is a premium dark-navy experience
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
