package com.example.firebase

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

private const val TAG = "JarvisAiClient"

class JarvisAiClient {

    private val model by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    suspend fun generateResponse(
        userMessage: String,
        recentHistory: List<Pair<String, String>> = emptyList()
    ): Result<String> {
        return try {
            withTimeout(45_000L) {
                val fullPrompt = buildString {
                    appendLine("You are JARVIS X, an elite, highly intelligent, concise, and loyal personal AI assistant running natively on the user's Android phone.")
                    appendLine("Respond politely and concisely. Seamlessly support English, Hindi, and natural everyday Hinglish.")
                    if (recentHistory.isNotEmpty()) {
                        appendLine("Recent conversation context:")
                        recentHistory.takeLast(4).forEach { (role, msg) ->
                            appendLine("$role: $msg")
                        }
                    }
                    appendLine("Current User Query: $userMessage")
                    appendLine("JARVIS X response:")
                }

                val response = model.generateContent(fullPrompt)
                val text = response.text?.trim()
                if (!text.isNullOrBlank()) {
                    Result.success(text)
                } else {
                    Result.failure(IllegalStateException("JARVIS X received an empty response from neural core."))
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "AI generation timed out", e)
            Result.failure(IllegalStateException("Request timed out. Please check your network connection."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Firebase AI generation error: ${e.message}", e)
            val friendlyMsg = when {
                e.message?.contains("AppCheck", ignoreCase = true) == true ->
                    "Security attestation pending. Ensure App Check is verified."
                e.message?.contains("403") == true ->
                    "Authentication attestation error (403). Running in offline fallback mode."
                e.message?.contains("Unable to resolve host") == true ->
                    "No active internet connection. Switched to offline mode."
                else -> e.localizedMessage ?: "Neural processing unavailable."
            }
            Result.failure(Exception(friendlyMsg, e))
        }
    }
}
