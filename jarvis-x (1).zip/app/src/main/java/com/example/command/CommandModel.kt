package com.example.command

import android.content.Intent

enum class CommandType {
    LOCAL_EXECUTION,   // Handled immediately inside app (e.g. Battery info, Current time, Notes)
    SAFE_INTENT,       // Direct safe system intent (e.g. Open Camera, Open Settings)
    SENSITIVE_INTENT,  // Requires explicit user dialog confirmation first (e.g. Dial, SMS, External URL, Clear History)
    AI_FALLBACK        // Pass to Gemini AI model
}

data class CommandAction(
    val id: String,
    val title: String,
    val description: String,
    val type: CommandType,
    val intent: Intent? = null,
    val feedbackMessage: String,
    val hindiFeedbackMessage: String? = null,
    val requiresConfirmation: Boolean = false,
    val isOfflineCapable: Boolean = true
)
