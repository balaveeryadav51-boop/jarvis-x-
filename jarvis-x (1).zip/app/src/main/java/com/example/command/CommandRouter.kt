package com.example.command

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CommandRouter(private val context: Context) {

    fun parseCommand(input: String, isHindiMode: Boolean = false): CommandAction? {
        val query = input.trim().lowercase(Locale.ROOT)

        // 1. Battery check (Offline capable)
        if (query.contains("battery") || query.contains("charging") || 
            query.contains("charge") || query.contains("battery kitni") || 
            query.contains("battery percentage")) {
            val batteryLevel = getBatteryLevel()
            val textEn = "Device battery level is at $batteryLevel%."
            val textHi = "Aapke device ki battery abhi $batteryLevel% par hai."
            return CommandAction(
                id = "CHECK_BATTERY",
                title = "Battery Status",
                description = "Check current battery and power level",
                type = CommandType.LOCAL_EXECUTION,
                feedbackMessage = if (isHindiMode) textHi else textEn,
                hindiFeedbackMessage = textHi,
                isOfflineCapable = true
            )
        }

        // 2. Current Time / Date (Offline capable)
        if (query.contains("what time") || query.contains("current time") || 
            query.contains("time kya") || query.contains("kitne baje") || 
            query.contains("samay kya") || query.contains("aaj ki date") || query.contains("today's date")) {
            val timeFormat = SimpleDateFormat("hh:mm a, EEEE, MMM d", Locale.getDefault())
            val currentTime = timeFormat.format(Date())
            val textEn = "The current time is $currentTime."
            val textHi = "Abhi samay $currentTime ho raha hai."
            return CommandAction(
                id = "CHECK_TIME",
                title = "System Clock",
                description = "Report current device time and date",
                type = CommandType.LOCAL_EXECUTION,
                feedbackMessage = if (isHindiMode) textHi else textEn,
                hindiFeedbackMessage = textHi,
                isOfflineCapable = true
            )
        }

        // 3. Clear History (Sensitive - requires confirmation!)
        if (query == "clear history" || query == "clear chat" || 
            query.contains("delete chat") || query.contains("chat clear") || 
            query.contains("history delete")) {
            return CommandAction(
                id = "CLEAR_HISTORY",
                title = "Clear Conversation History",
                description = "Erase all previous conversation records from local storage",
                type = CommandType.SENSITIVE_INTENT,
                requiresConfirmation = true,
                feedbackMessage = "Would you like me to purge all local conversation history?",
                hindiFeedbackMessage = "Kya aap saari chat history delete karna chahte hain?",
                isOfflineCapable = true
            )
        }

        // 4. Open Camera (Safe Intent)
        if (query.contains("open camera") || query.contains("camera kholo") || 
            query.contains("take photo") || query.contains("photo kheecho") || query.contains("start camera")) {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return CommandAction(
                id = "OPEN_CAMERA",
                title = "Launch Camera",
                description = "Open default camera viewfinder",
                type = CommandType.SAFE_INTENT,
                intent = intent,
                feedbackMessage = "Opening system camera viewfinder.",
                hindiFeedbackMessage = "Camera chalu kiya ja raha hai.",
                isOfflineCapable = true
            )
        }

        // 5. Open Settings (Safe Intent)
        if (query.contains("open settings") || query.contains("setting kholo") || 
            query.contains("device settings") || query.contains("system settings")) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return CommandAction(
                id = "OPEN_SETTINGS",
                title = "Open System Settings",
                description = "Launch Android settings dashboard",
                type = CommandType.SAFE_INTENT,
                intent = intent,
                feedbackMessage = "Accessing device system settings.",
                hindiFeedbackMessage = "Device ki settings khol raha hoon.",
                isOfflineCapable = true
            )
        }

        // 6. Open Wi-Fi (Safe Intent)
        if (query.contains("wifi") || query.contains("wi-fi") || query.contains("wireless")) {
            val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return CommandAction(
                id = "OPEN_WIFI",
                title = "Wi-Fi Settings",
                description = "Manage Wi-Fi network connections",
                type = CommandType.SAFE_INTENT,
                intent = intent,
                feedbackMessage = "Opening Wi-Fi configuration settings.",
                hindiFeedbackMessage = "Wi-Fi settings open kar raha hoon.",
                isOfflineCapable = true
            )
        }

        // 7. Open Bluetooth (Safe Intent)
        if (query.contains("bluetooth")) {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return CommandAction(
                id = "OPEN_BLUETOOTH",
                title = "Bluetooth Settings",
                description = "Manage Bluetooth paired devices",
                type = CommandType.SAFE_INTENT,
                intent = intent,
                feedbackMessage = "Opening Bluetooth settings.",
                hindiFeedbackMessage = "Bluetooth settings open kar raha hoon.",
                isOfflineCapable = true
            )
        }

        // 8. Open Alarms / Timers
        if (query.contains("alarm") || query.contains("alarm lagao") || query.contains("wake me up")) {
            val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return CommandAction(
                id = "OPEN_ALARM",
                title = "Alarm Clock",
                description = "View and manage device alarms",
                type = CommandType.SAFE_INTENT,
                intent = intent,
                feedbackMessage = "Opening your alarm clock.",
                hindiFeedbackMessage = "Alarm clock khol raha hoon.",
                isOfflineCapable = true
            )
        }

        // 9. Quick Local Note (Offline capable)
        if (query.startsWith("note ") || query.startsWith("take note") || 
            query.startsWith("save note") || query.startsWith("note likho") || query.startsWith("note banao")) {
            val noteContent = query.replace(Regex("^(note|take note|save note|note likho|note banao)\\s*"), "").trim()
            return CommandAction(
                id = "CREATE_NOTE",
                title = "Save Local Note",
                description = if (noteContent.isNotBlank()) noteContent else "Empty Note",
                type = CommandType.LOCAL_EXECUTION,
                feedbackMessage = if (noteContent.isNotBlank()) "Note saved securely: \"$noteContent\"" else "Please specify what you would like me to note down.",
                hindiFeedbackMessage = if (noteContent.isNotBlank()) "Aapka note save kar liya gaya hai: \"$noteContent\"" else "Kripya note ka content batayein.",
                isOfflineCapable = true
            )
        }

        // 10. Hindi Greetings & Persona quick answers (Offline capable)
        if (query == "namaste" || query == "namaste jarvis" || query == "hello" || query == "hi jarvis" || query == "hey jarvis") {
            val textEn = "Greetings. JARVIS X systems online and at your service."
            val textHi = "Namaste sir! Main JARVIS X hoon. Main aapki kya sahayata kar sakta hoon?"
            return CommandAction(
                id = "GREETING",
                title = "System Greeting",
                description = "Acknowledge user presence",
                type = CommandType.LOCAL_EXECUTION,
                feedbackMessage = if (isHindiMode) textHi else textEn,
                hindiFeedbackMessage = textHi,
                isOfflineCapable = true
            )
        }

        if (query.contains("aap kaise ho") || query.contains("how are you") || query.contains("kya haal hai")) {
            val textEn = "All internal diagnostics report optimal performance, sir. Ready for your instructions."
            val textHi = "Main bilkul theek hoon sir, saare systems normal hain! Aap batayein, kya karna hai?"
            return CommandAction(
                id = "STATUS_REPORT",
                title = "System Status",
                description = "Report assistant health",
                type = CommandType.LOCAL_EXECUTION,
                feedbackMessage = if (isHindiMode) textHi else textEn,
                hindiFeedbackMessage = textHi,
                isOfflineCapable = true
            )
        }

        // 11. Sensitive External Dialing or Web Search Intent (Confirmation required!)
        if (query.startsWith("search ") || query.startsWith("google ") || query.startsWith("search web for")) {
            val searchParam = query.replace(Regex("^(search|google|search web for)\\s*"), "").trim()
            if (searchParam.isNotBlank()) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(searchParam)}")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return CommandAction(
                    id = "SEARCH_WEB",
                    title = "Search the Web",
                    description = "Launch browser to search: \"$searchParam\"",
                    type = CommandType.SENSITIVE_INTENT,
                    intent = intent,
                    requiresConfirmation = true,
                    feedbackMessage = "Would you like me to open the browser to search for \"$searchParam\"?",
                    hindiFeedbackMessage = "Kya aap browser me \"$searchParam\" search karna chahte hain?",
                    isOfflineCapable = false
                )
            }
        }

        return null
    }

    private fun getBatteryLevel(): Int {
        return try {
            val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
                context.registerReceiver(null, filter)
            }
            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) {
                (level * 100 / scale.toFloat()).toInt()
            } else {
                85 // reasonable default if unavailable
            }
        } catch (e: Exception) {
            85
        }
    }
}
