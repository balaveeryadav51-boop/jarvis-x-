package com.example.audio

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * State of the on-device wake-word detection subsystem.
 */
sealed interface WakeWordStatus {
    data object Standby : WakeWordStatus
    data object ActiveListening : WakeWordStatus
    data class HardwareRequirementNotice(val message: String) : WakeWordStatus
}

/**
 * Modular interface for on-device wake-word detection.
 * Designed for pluggable offline keyword spotters such as:
 * - Picovoice Porcupine (wake word: "Jarvis")
 * - TensorFlow Lite Micro Keyword Spotting
 * - openWakeWord ONNX Runtime
 *
 * NOTE (Per safety and architectural constraints):
 * We do NOT simulate fake background wake-word triggers.
 * Continuous listening requires an OEM low-power audio DSP/NPU model and foreground service.
 */
interface WakeWordDetector {
    val status: StateFlow<WakeWordStatus>
    val isModelLoaded: Boolean
    val triggerPhrase: String

    fun startListening(onDetected: (String) -> Unit): Result<Unit>
    fun stopListening()
    fun getDiagnosticInfo(): String
}

class ModularWakeWordEngine : WakeWordDetector {

    private val _status = MutableStateFlow<WakeWordStatus>(WakeWordStatus.Standby)
    override val status: StateFlow<WakeWordStatus> = _status.asStateFlow()

    override val isModelLoaded: Boolean = false
    override val triggerPhrase: String = "Hey Jarvis"

    override fun startListening(onDetected: (String) -> Unit): Result<Unit> {
        // Honest hardware boundary:
        // On emulator and standard SDK builds without proprietary vendor DSP libraries,
        // we explicitly notify the user rather than faking active hardware hotword listening.
        val notice = "Wake-word detection requires a compiled on-device acoustic model (.ppn/.onnx) and OEM low-power DSP chip. Please use the prominent microphone button or user-enabled foreground service."
        _status.value = WakeWordStatus.HardwareRequirementNotice(notice)
        return Result.failure(UnsupportedOperationException(notice))
    }

    override fun stopListening() {
        _status.value = WakeWordStatus.Standby
    }

    override fun getDiagnosticInfo(): String {
        return """
            Engine: Modular Wake-Word Detector Architecture
            Target Phrase: "$triggerPhrase"
            Acoustic Backend: Pluggable (Porcupine / openWakeWord / TFLite)
            Status: Standby (Requires calibrated physical device microphone and vendor DSP binary)
            Safety Policy: Zero secret audio recording. Foreground notification required.
        """.trimIndent()
    }
}
