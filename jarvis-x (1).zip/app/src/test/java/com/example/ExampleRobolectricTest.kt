package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import com.google.firebase.Firebase
import com.google.firebase.ai.ai

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS X", appName)
  }

  @Test
  fun `test app check and ai client init`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    com.example.firebase.configureAppCheck(context, null)
    val client = com.example.firebase.JarvisAiClient()
    org.junit.Assert.assertNotNull(client)
    try {
      val model = com.google.firebase.Firebase.ai.generativeModel("gemini-3.8-flash")
      org.junit.Assert.assertNotNull(model)
    } catch (e: Throwable) {
      e.printStackTrace()
    }
  }
}
